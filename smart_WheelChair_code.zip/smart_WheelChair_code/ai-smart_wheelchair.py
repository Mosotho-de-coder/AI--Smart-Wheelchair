#*********************************************************#
#         AI-SMART WHEELCHAIR     BY  MOSOTHO THATHO
#         DEMO: https://youtu.be/L45GO1Molcc
#*********************************************************#
import threading, queue, time, json
import sounddevice as sd
import vosk
import numpy as np
from gpiozero import Robot, Motor, AngularServo, DigitalInputDevice,LED

# === Hardware setup ===
robot = Robot(left=Motor(17, 27), right=Motor(23, 24))
servo = AngularServo(22, min_angle=-90, max_angle=90)
servo.angle = 0  # center position
front_ir = DigitalInputDevice(4)   # OUT pin of front IR sensor
back_ir = DigitalInputDevice(18)   # OUT pin of rear IR sensor
red_led = LED(10)
green_led = LED(9)

# === Shared variables ===
command_queue = queue.Queue()
speed_limit = queue.Queue()
current_command = "stop"
speed = 0.5
servo_turn_done = threading.Event()
one_time_turn_done = threading.Event()
front_blocked = False
back_blocked = False

# === Vosk model ===
model = vosk.Model("/home/mosotho/model/vosk-model-small-en-us-0.15")

# === Resample ===
def resample(audio, orig_sr, target_sr=16000):
    duration = len(audio) / orig_sr
    target_length = int(duration * target_sr)
    return np.interp(
        np.linspace(0, len(audio), target_length, endpoint=False),
        np.arange(len(audio)),
        audio
    )

# === Servo worker ===
def servo_worker():
    """Handles servo motion for left/right commands with obstacle check."""
    global current_command, front_blocked

    while True:
        # Only react to left/right commands that haven’t already been executed
        if current_command in ["left", "right"] and not one_time_turn_done.is_set():
            turn_angle = 90 if current_command == "left" else -90
            print(f"[Servo] Turning {current_command} to {turn_angle}°")
            red_led.off()
            green_led.on()

            servo_start_time = time.time()
            servo_turn_done.clear()

            # Move servo gradually toward turn_angle
            step = 10 if turn_angle > 0 else -10
            for angle in range(0, turn_angle + step, step):
                # Check for obstacle during motion
                if front_ir.value == 0:
                    print("[Servo] Obstacle detected! Stopping and centering.")
                    red_led.on()
                    green_led.off()
                    servo.angle = 0
                    robot.stop()
                    current_command = "stop"
                    one_time_turn_done.set()
                    break

                servo.angle = angle
                time.sleep(0.05)  # adjust for smoother or faster turning
            else:
                # Return to center after reaching full turn if no obstacle
                print("[Servo] Centering back to 0°")
                for angle in range(turn_angle, 0, -step):
                    # Check again while returning
                    if front_ir.value == 0:
                        print("[Servo] Obstacle detected during return! Stopping and centering.")
                        red_led.on()
                        green_led.off()
                        servo.angle = 0
                        robot.stop()
                        current_command = "stop"
                        one_time_turn_done.set()
                        break
                    servo.angle = angle
                    time.sleep(0.05)
                else:
                    servo.angle = 0
                    print("[Servo] Centered again successfully.")
                    servo_turn_done.set()
                    one_time_turn_done.set()

        else:
            servo_turn_done.clear()

        time.sleep(0.05)

# === Hardware controller ===
def hardware_controller():
    """Handles motor movement for wheelchair with IR obstacle detection."""
    global current_command, front_blocked, back_blocked, speed

    while True:
        # Get next command if available
        red_led.off()
        green_led.on()
        if not command_queue.empty():
            robot.stop()
            new_cmd = command_queue.get()
            command_queue.task_done()
            current_command = new_cmd
            one_time_turn_done.clear()  # reset for new command
            print(f"[Hardware] New command: {current_command}")
            
        if not speed_limit.empty():
            speed = speed_limit.get()
            print(f"[Hardware] Speed updated: {speed}")
            speed_limit.task_done()

        # Read IR sensors (0 = obstacle)
        front_blocked = (front_ir.value == 0)
        back_blocked = (back_ir.value == 0)

        # Obstacle handling
        if front_blocked and current_command in ["forward", "left", "right", "backward"]:
            print("Front obstacle detected! Reversing briefly...")
            red_led.on()
            green_led.off()
            robot.backward(speed)
            time.sleep(0.5)
            robot.stop()
            current_command = "stop"

        elif back_blocked and current_command in ["forward", "left", "right", "backward"]:
            print("Rear obstacle detected! Moving forward briefly...")
            red_led.on()
            green_led.off()
            robot.forward(speed)
            time.sleep(0.5)
            robot.stop()
            current_command = "stop"

        else:
            # Continuous motion commands
            if current_command == "forward":
                robot.forward(speed)
            elif current_command in ["backward", "reverse"]:
                robot.backward(speed)
            elif current_command == "stop":
                robot.stop()
            elif current_command in ["left", "right"] and not one_time_turn_done.is_set():
                servo_turn_done.wait(timeout=1.5)
                servo_turn_done.clear()

                if current_command in ["left", "right"]:
                    print(f"[Hardware] Turning wheels {current_command} once...")

                    turn_start = time.time()
                    turn_duration = 0.8  # how long the wheel turn lasts

        # Start turning
                    if current_command == "left":
                        robot.left(speed)
                    else:
                        robot.right(speed)

        # Check for obstacle during the turn loop
                    while time.time() - turn_start < turn_duration:
                        front_blocked = (front_ir.value == 0)
                        back_blocked = (back_ir.value == 0)

                        if front_blocked:
                            print("[Hardware] Front obstacle detected during turn! Stopping immediately.")
                            red_led.on()
                            green_led.off()
                            robot.backward(speed)
                            time.sleep(0.4)
                            robot.stop()
                            current_command = "stop"
                            one_time_turn_done.set()
                            break
                        elif back_blocked:
                            print("[Hardware] Rear obstacle detected during turn! Stopping immediately.")
                            red_led.on()
                            green_led.off()
                            robot.forward(speed)
                            time.sleep(0.4)
                            robot.stop()
                            current_command = "stop"
                            one_time_turn_done.set()
                            break

                        time.sleep(0.05)  # check roughly 20 times per second

        # If no obstacle interrupted the turn
                    else:
                        robot.stop()
                        print("[Hardware] Turn complete safely.")

                    one_time_turn_done.set()
                    current_command = "stop"
            

# === Voice listener ===
def voice_listener():
    """Listens continuously for voice commands using Vosk."""
    rec = vosk.KaldiRecognizer(model, 16000)

    def callback(indata, frames, time_info, status):
        if status:
            print("Audio status:", status)
        audio = indata[:, 0]
        audio_16k = resample(audio, 48000, 16000)
        audio_bytes = (audio_16k * 32767).astype(np.int16).tobytes()

        if rec.AcceptWaveform(audio_bytes):
            result = json.loads(rec.Result())
            text = result.get("text", "").lower()
            if text:
                print("[Voice] Heard:", text)
                if "i hate" in text or "for what" in text:
                    command_queue.put("forward")
                elif "back" in text or "reverse" in text:
                    command_queue.put("backward")
                elif "left" in text or "turn left" in text:
                    command_queue.put("left")
                elif "right" in text or "turn right" in text:
                    command_queue.put("right")
                elif "stop" in text or "pause" in text:
                    command_queue.put("stop")
                    
                elif "fast" in text or "faster" in text:
                    speed_limit.put(1.0)
                    
                elif "moderate" in text or "medium" in text:
                    speed_limit.put(0.7)
                    
                elif "slow" in text or "slower" in text:
                    speed_limit.put(0.5)

    with sd.InputStream(
        samplerate=48000,
        blocksize=16000,
        dtype="float32",
        channels=1,
        callback=callback
    ):
        print("Listening for: 'forward', 'backward', 'left', 'right', 'stop'")
        while True:
            time.sleep(0.1)

# === Launch threads ===
threads = [
    threading.Thread(target=voice_listener, daemon=True),
    threading.Thread(target=hardware_controller, daemon=True),
    threading.Thread(target=servo_worker, daemon=True),
]

for t in threads:
    t.start()

# === Keep alive ===
while True:
    time.sleep(1)
